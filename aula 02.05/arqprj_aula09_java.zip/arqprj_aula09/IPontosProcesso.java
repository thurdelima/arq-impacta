package pontos.interfaces;

public interface IPontosProcesso {
	Mapeamento getMapeamento();
	int getPontos(int identificador, String letras, Mapeamento mapeamento);
}
