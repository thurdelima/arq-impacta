package pontos.interfaces;

public interface IPontosBusiness {
	Participante find(int identificador);
}
